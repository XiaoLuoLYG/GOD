---
instruction: 发送一条公开群聊。内容：各位老师同学好，代表团已经准备开始今天的公开交流流程。我们先听学生问题，再作简短回应，请保持自然交流节奏。
target:
  type: agent
  agent_id: 22
---

已接收干预，并投递给 王协调员 (agent_id=22)。
手动模式下不会自动执行下一步；请点击 Run Step 或开启 Auto 后，该干预会进入后续 step 并写入 replay。

王协调员 (agent_id=22): 已实时投递到该 agent 的 pending interventions；下一次 step prompt 会包含这条干预并要求优先执行。若识别为紧急公共事件，会先自动广播到小镇群组。
